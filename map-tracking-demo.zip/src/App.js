import React from 'react'
import MapContainer from './MapContainer'
const App = () => {
  return (
    <div>
      <MapContainer/>
    </div>
  )
}

export default App
